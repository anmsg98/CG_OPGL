실행파일과 같은 폴더에 fmod.dll 이 필요합니다.

깃허브 링크
https://github.com/sunkue/CG_OPGL

유투브 발표 영상 링크
https://youtu.be/h2xhVri48uE